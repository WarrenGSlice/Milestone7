package com.example.contactsapp1;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.List;

public class EditContact extends AppCompatActivity {
    Button btn_Save, btn_exit, btn_delete, btn_call,btn_text, btn_email, btn_maps;
    List<People> peopleList;
    EditText et_personName, et_PersonDate, et_PersonImageUrl, et_personStreet, et_personCity, et_personZip, et_personState, et_personCountry, et_personEmail, et_personPhone;
    TextView tv_idNumber;
    int id;

    final static int PERMISSION_TO_CALL = 1;

    MyApplication myApplication = (MyApplication) this.getApplication();

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_contact);

        peopleList = myApplication.getPeopleList();

        btn_delete = findViewById(R.id.btn_delete);
        btn_Save = findViewById(R.id.btn_Save);
        btn_exit = findViewById(R.id.btn_exit);
        btn_call = findViewById(R.id.btn_call);
        btn_text = findViewById(R.id.btn_text);
        btn_email = findViewById(R.id.btn_email);
        btn_maps = findViewById(R.id.btn_maps);
        et_personName = findViewById(R.id.et_personName);
        et_PersonDate = findViewById(R.id.et_PersonDate);
        et_PersonImageUrl = findViewById(R.id.et_PersonImageUrl);
        et_personStreet = findViewById(R.id.et_personStreet);
        et_personCity = findViewById(R.id.et_personCity);
        et_personZip = findViewById(R.id.et_personZip);
        et_personState = findViewById(R.id.et_personState);
        et_personCountry = findViewById(R.id.et_personCountry);
        et_personEmail = findViewById(R.id.et_personEmail);
        tv_idNumber = findViewById(R.id.tv_idNumber);
        et_personPhone = findViewById(R.id.et_PersonPhone);

        Intent intent = getIntent();

        id = intent.getIntExtra("id", -1);
        People people = null;

        if (id >=0) {
            //edit the contact
            for (People p: peopleList) {
                if (p.getId() == id ) {
                    people = p;
                }
            }
            et_personName.setText(people.getName());
            et_PersonImageUrl.setText(people.getImageURL());
            et_PersonDate.setText(String.valueOf(people.getDateOfBirth()));
            tv_idNumber.setText(String.valueOf(id));
            et_personCity.setText(people.getCity());
            et_personCountry.setText(people.getCountry());
            et_personEmail.setText(people.getEmail());
            et_personStreet.setText(people.getStreet());
            et_personState.setText(people.getState());
            et_personZip.setText(String.valueOf(et_personZip));
            et_personPhone.setText(people.getPhone());
        }
        else {
            // create new person
        }

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (id >=0) {

                    //Update
                    People updatedPeople = new People(id,et_personName.getText().toString(), Integer.parseInt(et_PersonDate.getText().toString()), et_PersonImageUrl.getText().toString(), et_personStreet.getText().toString(), et_personCity.getText().toString(), et_personState.getText().toString(), et_personZip.getText().toString(), et_personCountry.getText().toString(), et_personEmail.getText().toString(), et_personPhone.getText().toString());
                    peopleList.set(id, updatedPeople);
                }
                else{
                    // add new person
                    //Create Person object
                    int nextId = MyApplication.getNextId();
                    People newPeople = new People(nextId,et_personName.getText().toString(), Integer.parseInt(et_PersonDate.getText().toString()), et_PersonImageUrl.getText().toString(), et_personStreet.getText().toString(), et_personCity.getText().toString(), et_personState.getText().toString(), et_personZip.getText().toString(), et_personCountry.getText().toString(), et_personEmail.getText().toString(), et_personPhone.getText().toString());

                    //add the object of the global list of people
                    peopleList.add(newPeople);
                    MyApplication.setNextId(nextId++);
                }

                //go back to main activity
                Intent intent = new Intent(EditContact.this, ContactList.class);
                startActivity(intent);
            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditContact.this, ContactList.class);
                startActivity(intent);
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Remove the contact from the list
                id = intent.getIntExtra("id", -1);
                People people = null;
                if (id >=0) {
                    //edit the contact
                    for (People p: peopleList) {
                        if (p.getId() == id ) {
                            people = p;
                        }
                    }
                    peopleList.remove(people);
                    Intent intent = new Intent(EditContact.this, ContactList.class);
                    startActivity(intent);
                }
            }
        });

        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callPhoneNumber(et_personPhone.getText().toString());
            }
        });

        btn_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                composeMessage(et_personPhone.getText().toString(), "Hello I would like to talk");
            }
        });

        btn_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String [] addresses = new String[1];
                addresses[0] = et_personEmail.getText().toString();
                composeEmail( addresses, "Hello from Warren");
            }
        });

        btn_maps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mapsQuery = "geo:0,0?q=" + et_personStreet.getText().toString() + et_personCity.getText().toString();
                Uri mapuri = Uri.parse(mapsQuery);
                showMap(mapuri);
            }
        });
    }

    public void callPhoneNumber(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + phoneNumber));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            ActivityCompat.requestPermissions(EditContact.this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    PERMISSION_TO_CALL);
        }
        else {
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_TO_CALL:
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    callPhoneNumber(et_personPhone.getText().toString());
                }  else {
                    Toast.makeText(this, "Cannot make a call without permission", Toast.LENGTH_SHORT).show();
                }
                return;
        }
        // Other 'case' lines to check for other
        // permissions this app might request.
    }

    public void composeMessage(String phoneNumber, String message) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:" + phoneNumber));  // This ensures only SMS apps respond
        intent.putExtra("sms_body", message);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void composeEmail(String[] addresses, String subject) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void showMap(Uri geoLocation) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(geoLocation);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}
