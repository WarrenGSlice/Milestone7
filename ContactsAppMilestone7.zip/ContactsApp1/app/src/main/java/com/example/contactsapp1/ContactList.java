package com.example.contactsapp1;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;

public class ContactList extends AppCompatActivity {

    private static final String TAG = "People App";
    Button btn_exit;
    Menu menu;

    MyApplication myApplication = (MyApplication) this.getApplication();

    List<People> peopleList;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact_list_layout);

        peopleList = MyApplication.getPeopleList();

        Log.d(TAG, "onCreate: " + peopleList.toString());
        Toast.makeText(ContactList.this, "People count = " + peopleList.size(), Toast.LENGTH_SHORT).show();
        btn_exit = findViewById(R.id.btn_exit);

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContactList.this, MainMenu.class);
                startActivity(intent);
            }
        });

        recyclerView = findViewById(R.id.lv_peopleList);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mAdapter = new RecyclerViewAdapter(peopleList, ContactList.this);
        recyclerView.setAdapter(mAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.sort_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch(item.getItemId()) {
            case R.id.menu_aToZ:
                // sort a to z
                Collections.sort(peopleList, People.PeopleNameAZComparator);
                Toast.makeText(ContactList.this, "Sort A to Z", Toast.LENGTH_SHORT).show();
                mAdapter.notifyDataSetChanged();
                return true;
            case R.id.menu_zToA:
                // sort z to a
                Collections.sort(peopleList, People.PeopleNameZAComparator);
                Toast.makeText(ContactList.this, "Sort Z to A", Toast.LENGTH_SHORT).show();
                mAdapter.notifyDataSetChanged();
                return true;
            case R.id.menu_dateAscending:
                // sort date Ascending
                Collections.sort(peopleList, People.PeopleDateAscendingComparator);
                Toast.makeText(ContactList.this, "Sort Date Ascending", Toast.LENGTH_SHORT).show();
                mAdapter.notifyDataSetChanged();
                return true;
            case R.id.menu_dateDescending:
                // sort date Descending
                Collections.sort(peopleList, People.PeopleDateDescendingComparator);
                Toast.makeText(ContactList.this, "Sort Date Descending", Toast.LENGTH_SHORT).show();
                mAdapter.notifyDataSetChanged();
                return true;
            case R.id.menu_IdAscending:
                // sort ID Ascending
                Collections.sort(peopleList, People.PeopleIdAscendingComparator);
                Toast.makeText(ContactList.this, "Sort ID Ascending", Toast.LENGTH_SHORT).show();
                mAdapter.notifyDataSetChanged();
                return true;
            case R.id.menu_IdDescending:
                // sort ID Descending
                Collections.sort(peopleList, People.PeopleIdDescendingComparator);
                Toast.makeText(ContactList.this, "Sort ID Descending", Toast.LENGTH_SHORT).show();
                mAdapter.notifyDataSetChanged();
                return true;

        }

        return super.onOptionsItemSelected(item);
    }
}
