package com.example.contactsapp1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    List<People> peopleList;
    Context context;

    public RecyclerViewAdapter(List<People> peopleList, Context context) {
        this.peopleList = peopleList;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.one_line_contact_page, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.MyViewHolder holder, int position) {
        holder.tv_pplName.setText(peopleList.get(position).getName());
        holder.tv_dateOfBirth.setText(String.valueOf(peopleList.get(position).getDateOfBirth()));
        Glide.with(this.context).load(peopleList.get(position).getImageURL()).into(holder.iv_peoplePic);
        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // send the control to the EditOneItem Activity
                Intent intent = new Intent(context, EditContact.class);
                intent.putExtra("id", peopleList.get(position).getId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return peopleList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_peoplePic;
        TextView tv_pplName;
        TextView tv_dateOfBirth;
        ConstraintLayout parentLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_peoplePic = itemView.findViewById(R.id.iv_peoplePic);
            tv_dateOfBirth = itemView.findViewById(R.id.tv_dateOfBirth);
            tv_pplName = itemView.findViewById(R.id.tv_pplName);
            parentLayout = itemView.findViewById(R.id.oneLinePeopleLayout);
        }
    }
}
