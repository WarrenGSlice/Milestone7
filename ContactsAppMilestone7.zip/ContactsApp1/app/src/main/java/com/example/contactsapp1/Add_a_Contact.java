package com.example.contactsapp1;

import android.app.Person;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class Add_a_Contact extends AppCompatActivity {

    Button btn_exit, btn_AddContactPage, btn_Save;
    List<People> peopleList;
    EditText et_personName, et_personDate, et_personEmail, et_personState, et_personCity, et_personZip, et_personStreet, et_personImageUrl, et_personCountry, et_personPhone;
    TextView tv_idNumber;
    int id;

    MyApplication myApplication = (MyApplication) this.getApplication();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_a_contact);

        peopleList = MyApplication.getPeopleList();

        btn_exit = findViewById(R.id.btn_exit);
        btn_AddContactPage = findViewById(R.id.btn_AddContactPage);
        btn_Save = findViewById(R.id.btn_Save);
        et_personCity = findViewById(R.id.et_pplCity);
        et_personCountry = findViewById(R.id.et_pplCountry);
        et_personDate = findViewById(R.id.et_pplDOB);
        et_personEmail = findViewById(R.id.et_pplEmail);
        et_personImageUrl = findViewById(R.id.et_pplImage);
        et_personName = findViewById(R.id.et_pplName);
        et_personState = findViewById(R.id.et_pplState);
        et_personStreet = findViewById(R.id.et_pplStreet);
        et_personZip = findViewById(R.id.et_pplZip);
        tv_idNumber = findViewById(R.id.tv_idNumber);
        et_personPhone = findViewById(R.id.et_pplPhone);

        Intent intent = getIntent();
        //What is happening: IS ID > -1?   YES= edit form, NO= exit
        id = intent.getIntExtra("id", -1);
        People people = null;

        if (id >=0) {
            //edit the contact
            for (People p: peopleList) {
                if (p.getId() == id ) {
                    people = p;
                }
            }
            et_personName.setText(people.getName());
            et_personImageUrl.setText(people.getImageURL());
            et_personDate.setText(String.valueOf(people.getDateOfBirth()));
            tv_idNumber.setText(String.valueOf(id));
            et_personCity.setText(people.getCity());
            et_personCountry.setText(people.getCountry());
            et_personEmail.setText(people.getEmail());
            et_personStreet.setText(people.getStreet());
            et_personState.setText(people.getState());
            et_personZip.setText(String.valueOf(et_personZip));
            et_personPhone.setText(people.getPhone());
        }
        else {
            // create new person
        }

        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (id >=0) {

                    //Update
                    People updatedPeople = new People(id,et_personName.getText().toString(), Integer.parseInt(et_personDate.getText().toString()), et_personImageUrl.getText().toString(), et_personStreet.getText().toString(), et_personCity.getText().toString(), et_personState.getText().toString(), et_personZip.getText().toString(), et_personCountry.getText().toString(), et_personEmail.getText().toString(), et_personPhone.getText().toString());
                    peopleList.set(id, updatedPeople);
                }
                else {
                    // add new person
                    //Create Person object
                    int nextId = MyApplication.getNextId();
                    People newPeople = new People(nextId,et_personName.getText().toString(), Integer.parseInt(et_personDate.getText().toString()), et_personImageUrl.getText().toString(), et_personStreet.getText().toString(), et_personCity.getText().toString(), et_personState.getText().toString(), et_personZip.getText().toString(), et_personCountry.getText().toString(), et_personEmail.getText().toString(), et_personPhone.getText().toString());

                    //add the object of the global list of people
                    peopleList.add(newPeople);
                    MyApplication.setNextId(nextId++);
                }

                //go back to main activity
                Intent intent = new Intent(Add_a_Contact.this, MainMenu.class);
                startActivity(intent);
            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Add_a_Contact.this, MainMenu.class);
                startActivity(intent);
            }
        });
    }

}
